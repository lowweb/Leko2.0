
// document.querySelector(".ham").onclick = function() {
//   document.querySelector(".ham").classList.toggle('open');
//     // document.getElementsByClassName('menu__nav')[0].classList.toggle('menu__nav--opn');
//   };